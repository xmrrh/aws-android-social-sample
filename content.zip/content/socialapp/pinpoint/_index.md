---
title: "Send Push message"
chapter: true
weight: 70
---

#Send Push message

Let's practice using Amazon Ponpoint to send PUSH notifications to users who have your app installed. 

