---
title: "Create Android Studio Project"
chapter: false
weight: 32
---

Start **Android Studio**.

Select **Open an existing Android Studio project**.

![c9after](/images/openproject.png)

Select the downloaded source directory.

When the project is created, it should look like the following. Make sure there are no issues with your build
![c9after](/images/openprojectandbuild.png)

Press **Run button** at the top of your Android Studio project to run it with the emulator you've already created.
![c9after](/images/run.png)

It looks like this: 
![c9after](/images/emul.png)

You are now ready for the lab. Now let's complete the features one by one using AWS services.

