---
title: "Integrating Amazon Translate"
chapter: true
weight: 50
---

# Integrating Amazon Translate

Now, let's integrate Amazon Translate, which can translate the title and content of posts into various languages.
