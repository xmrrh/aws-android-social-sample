---
title: "Start workshop"
chapter: true
weight: 10
---

# Start workshop

This workshop requires an AWS account.



The sample code is based on Android-**JAVA**.

No sample code is provided for Kotlin users.



<br><br>

