---
title: "Create an application"
chapter: true
weight: 23
---

# Create an application

The architects used in this workshop are as follows. 

![Example Service](/images/architecture.png)

