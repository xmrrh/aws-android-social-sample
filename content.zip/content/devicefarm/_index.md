---
title: "DeviceFarm 테스트"
chapter: true
weight: 301
---

# DeviceFarm 테스트

빌드 된 앱을 DeviceFarm으로 간단히 구동해보고, 병렬 테스트를 수행합니다.
이 테스트에서는 Fuzzy 테스트와 Frame Work 순차 테스트를 진행합니다.



<br><br>