---
title: "Clean up"
chapter: true
weight: 70
---

# Clean up

Delete the resources used in this workshop.

