---
title: "Android Amplify Initialization"
chapter: true
weight: 1
---

# Android Amplify Initialization

Let's use Android Amplify for easy back-end development of generated sample application.
