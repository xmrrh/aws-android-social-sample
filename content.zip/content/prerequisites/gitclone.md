---
title: "Clone Workshop Repository"
chapter: false
weight: 22
---

Copy the repository containing the source files for the lab.
```
git clone https://github.com/xmrrh/aws-android-workshop.git
```

If you don't have git installed, please go to the following page and **download zip** the source and unzip it.. 

https://github.com/xmrrh/aws-android-workshop



![Create User](/images/downloadsrc.png)

