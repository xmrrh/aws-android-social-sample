---
title: "Create a social post repository"
chapter: true
weight: 4
---

# Create a social post repository

Simplify application development by creating data storage and access APIs with AWS AppSync.
