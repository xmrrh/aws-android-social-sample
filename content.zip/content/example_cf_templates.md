---
title: "Example of using CloudFormation Templates"
---


#### Click below to add a CloudFormation Stack

| Use these templates: |  |  |
| ------ |:------:|:--------:| 
| Template 1 example |  {{% cf-launch "example1.yml" %}} | {{% cf-download "example1.yml" %}}  |
| Template 2 example |  {{% cf-launch "example2.yml" %}} | {{% cf-download "example2.yml" %}}  |
| Template 3 example |  {{% cf-launch "example3.yml" %}} | {{% cf-download "example3.yml" %}}  |





